var searchData=
[
  ['třetí_20úkol',['Třetí úkol',['../group__task3.html',1,'']]]
];
