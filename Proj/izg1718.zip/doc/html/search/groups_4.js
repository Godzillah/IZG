var searchData=
[
  ['první_20úkol',['První úkol',['../group__task1.html',1,'']]]
];
