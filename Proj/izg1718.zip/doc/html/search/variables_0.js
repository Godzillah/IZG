var searchData=
[
  ['attributes',['attributes',['../structGPUVertexShaderInput.html#a01f1182e46873cccea824f74f0545adf',1,'GPUVertexShaderInput::attributes()'],['../structGPUFragmentAttributes.html#af2ea62c0bcd0c007607fecb9ca8f73d7',1,'GPUFragmentAttributes::attributes()'],['../structGPUFragmentShaderInput.html#ac222496adf3fb044cebcd79693b8962e',1,'GPUFragmentShaderInput::attributes()'],['../structGPUVertexShaderOutput.html#acb55a42bf173ac38ad5a9c0951758e52',1,'GPUVertexShaderOutput::attributes()'],['../structGPUVertexPullerOutput.html#aea734793f0b20b263d90d9abaf582fe5',1,'GPUVertexPullerOutput::attributes()']]]
];
