var searchData=
[
  ['pixel_5fcenter',['PIXEL_CENTER',['../fwd_8h.html#ae076859973ad39323fe4a2cbd21a9145',1,'fwd.h']]]
];
