var searchData=
[
  ['edges_5fper_5ftriangle',['EDGES_PER_TRIANGLE',['../fwd_8h.html#a9f5bff3a2ab411701ed6262d5eb96c39',1,'fwd.h']]]
];
