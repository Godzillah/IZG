var searchData=
[
  ['inicializace',['Inicializace',['../group__init.html',1,'']]]
];
