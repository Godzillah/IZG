var searchData=
[
  ['reflect',['reflect',['../linearAlgebra_8c.html#a99d9fc7339bdd41ad0224926a11b4b2b',1,'reflect(Vec3 *const output, Vec3 const *const incident, Vec3 const *const normal):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a99d9fc7339bdd41ad0224926a11b4b2b',1,'reflect(Vec3 *const output, Vec3 const *const incident, Vec3 const *const normal):&#160;linearAlgebra.c']]],
  ['rotate_5fmat4',['rotate_Mat4',['../linearAlgebra_8c.html#a07a5d933b90b3c5929a3a2a8e37405ba',1,'rotate_Mat4(Mat4 *const output, float const u, float const v, float const w, float const angle):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a07a5d933b90b3c5929a3a2a8e37405ba',1,'rotate_Mat4(Mat4 *const output, float const u, float const v, float const w, float const angle):&#160;linearAlgebra.c']]]
];
