var searchData=
[
  ['triangleexamplevariables',['TriangleExampleVariables',['../structTriangleExampleVariables.html',1,'']]]
];
